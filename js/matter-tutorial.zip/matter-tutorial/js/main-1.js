const 
  Engine = Matter.Engine, 
  World = Matter.World, 
  Bodies = Matter.Bodies, 
  Runner = Matter.Runner,
  Mouse = Matter.Mouse, 
  MouseConstraint = Matter.MouseConstraint;

const cat = {
  static:    0x0001,
  nodrag:    0x0002,
  drag:      0x0004
};

let canvas;

/* Matter.js */
const engine = Engine.create();
const world = engine.world;

engine.gravity.y = 0;

/* Proměnné typu pole pro uložení grafických objektů */
let boxes = [];
let circles = [];
let walls = [];
/* Proměnná pro akce vyvolané myší */
let mConstraint;

/* Třída pro vytvoření statických objektů - zdí */
class Wall {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.options = {
      friction: 0.3,
      restitution: 0.6,
      isStatic: true
    };
    this.body = Bodies.rectangle(x, y, w, h, this.options); 
    World.add(world, this.body);
  }
  
  draw() {
    let pos = this.body.position;
    push();
    translate(pos.x, pos.y);
    rotate(this.body.angle);
    rectMode(CENTER);
    strokeWeight(1);
    noStroke();
    fill(255,0,0);
    rect(0, 0, this.w, this.h);
    pop();
  }
}

/* Třída pro vytvoření obdélníkových objektů */
class Box {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.options = {
      friction: 0.3,
      restitution: 0.6,
      collisionFilter: { category: cat.nodrag },      
      isStatic: false
    };
    this.body = Bodies.rectangle(x, y, w, h, this.options);
    World.add(world, this.body);
  }
  
  draw() {
    let pos = this.body.position;
    push();
    translate(pos.x, pos.y);
    rotate(this.body.angle);
    rectMode(CENTER);
    strokeWeight(1);
    stroke(255);
    fill(127);    
    rect(0, 0, this.w, this.h);
    pop();
  }
}

/* Třída pro vytvoření kruhových objektů */
class Circle {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
    this.options = {
      friction: 0.3,
      restitution: 0.6,
      isStatic: false
    };
    this.body = Bodies.circle(x, y, r, this.options);
    World.add(world, this.body);
  }

  draw() {
    let pos = this.body.position;
    push();
    translate(pos.x, pos.y);
    rotate(this.body.angle);
    rectMode(CENTER);
    strokeWeight(1);
    stroke(255);
    fill(127);
    circle(0, 0, this.r * 2);
    pop();
  }
}


/* Funkce pro základní nastavení aplikace v P5 JS */
function setup() {
  /* Vytvoří plátno podle velikosti displeje: https://p5js.org/reference/#/p5/createCanvas */
  canvas = createCanvas(displayWidth, displayHeight);
  // Spuštění stroje (engine)
  Runner.run(engine);
  // Vytvoření zdí
  walls.push(new Wall(0, height / 2, 30, height));
  walls.push(new Wall(width, height / 2, 30, height));
  walls.push(new Wall(width / 2, 0, width, 30));
  walls.push(new Wall(width / 2, height, width, 30));

  /* Vytvoření myši */
  let mouse = Mouse.create(canvas.elt);
  mouse.pixelRatio = pixelDensity() // for retina displays etc
  let options = {
    mouse: mouse
  }
  /* Propojení myši s engine */
  mConstraint = MouseConstraint.create(engine, options);
  mConstraint.collisionFilter.mask = cat.static | cat.drag;
  World.add(world, mConstraint); 
}

/* Funkce pro vykreslení plátna */
function draw() {
  /* Nastaví černou barvu pozadí: https://p5js.org/reference/#/p5/background */
  background(0);
  /* Aktualizace engine */
  Engine.update(engine);
  /* Vykreslení zdí */
  walls.forEach((wall) => {
    wall.draw();
  });
  /* Vykreslení obdélníků */
  boxes.forEach((box) => {
    box.draw();
  });
  /* Vykreslení kruhů */
  circles.forEach((circle) => {
    circle.draw();
  });  
}

/* Funkce pro změnu velikosti plátna podle velikosti okna */
function windowResized() {
  /* Změní velikost plátna podle rozměrů okna: https://p5js.org/reference/#/p5/resizeCanvas */
  resizeCanvas(windowWidth, windowHeight);
}

/* Ošetření události myši */
function mousePressed(event) {
  if (mouseButton === RIGHT && keyIsDown(66)) {
    boxes.push(new Box(mouseX, mouseY, random(10, 50), random(10, 50)));  
  }
  if (mouseButton === RIGHT && keyIsDown(67)) {
    circles.push(new Circle(mouseX, mouseY, random(10, 50)));  
  }  
}

