# ASTEROIDS game in p5.js
## Tutorial for beginners

### Tools & technologies
* VSCode
* Javascript ES6
* p5.js