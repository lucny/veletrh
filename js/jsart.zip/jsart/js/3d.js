let keyframe;
let cracks = [];
let cam1, cam2;
let currentCamera;
let delta = 2;

/* Funkce pro základní nastavení aplikace v P5 JS */
function setup() {
  /* Vytvoří plátno podle velikosti displeje: https://p5js.org/reference/#/p5/createCanvas */
  canvas = createCanvas(displayWidth, displayHeight, WEBGL);
  cam1 = createCamera();
  cam1.setPosition(-300, -30, 500);
  cam1.pan(-0.8);
  cam2 = createCamera();
  cam2.setPosition(30, 0, 50);
  cam2.lookAt(1000, 0, 100);
  cam2.ortho();
  currentCamera = 1;
}

/* Funkce pro vykreslení plátna */
function draw() {
  /* Nastaví černou barvu pozadí: https://p5js.org/reference/#/p5/background */
  background(0);
  // camera 1:
  cam1.lookAt(0, 0, 0);
  cam1.setPosition(sin(frameCount / 60) * 200, 0, 100);
  cam1.pan(delta);
  // every 160 frames, switch direction
  if (frameCount % 160 === 0) {
    delta *= -1;
  }

  // every 100 frames, switch between the two cameras
  if (frameCount % 100 === 0) {
    if (currentCamera === 1) {
      setCamera(cam1);
      currentCamera = 0;
    } else {
      setCamera(cam2);
      currentCamera = 1;
    }
  }
  fill('rgba(50, 50, 50, 0.1)');
  orbitControl();
  rotateX(frameCount * 0.001);
  rotateY(frameCount * 0.001);
  box(500);  
  fill('rgba(50, 5, 5, 0.05)');
  box(600);
  cracks.forEach((crack, idx, arr) => {
    crack.draw();
  });  
}

/* Funkce pro změnu velikosti plátna podle velikosti okna */
function windowResized() {
  /* Změní velikost plátna podle rozměrů okna: https://p5js.org/reference/#/p5/resizeCanvas */
  resizeCanvas(windowWidth, windowHeight);
}

function mousePressed() {
    keyframe = frameCount;
}
  
function mouseReleased() {
    cracks.push(new Crack(mouseX, mouseY, frameCount - keyframe));
}
  
