let monoSynth;
monoSynth = new p5.MonoSynth();
const notes = ['C2', 'Db2', 'D2', 'Eb2', 'E2', 'F2', 'Gb2', 'G2', 'Hb2', 'H2', 'C3'];

class Crack {
    constructor(posX, posY, radius) {
        this.x = posX;
        this.y = posY;
        this.r = radius;
        this.crackpoints = [];
        this.color = `rgba(${round(random(156))}, ${round(random(156))}, ${round(random(156))}, ${random(0, 1)})`;
        this.frames = frameCount;
        this.generatePoints();
    }
    
    generatePoints() {
        for (let i = 1; i <= this.r; i++) {
            let dist = random(this.r * 2 / 3, this.r);
            point = {
                angle: (2 * PI / this.r) * i,
                dist: dist
            }   
            this.crackpoints.push(point);
        }
        print(this.crackpoints);
    }

    pulse() {
        this.crackpoints.map((point, idx, arr) => {
            point.dist += random(-5, 5);
        });
    }

    draw(cracks) {
        this.pulse();
        noFill();
        stroke(this.color);
        strokeWeight(1);
        smooth();
        beginShape();
        this.x += random(-2, 2);
        this.y += random(-2, 2);
        this.crackpoints.forEach((point, idx, arr) => {
            let x = this.x + round((cos(point.angle) * point.dist)); 
            let y = this.y + round((sin(point.angle) * point.dist));
            //curveVertex(x, y);
            circle(x, y, 5);
            line(this.x, this.y, x, y);
            //monoSynth.play(this.x, 0.5 - 1/this.dist, 0, 0.15);
            if (point.dist > 100) {
                cracks.push(new Crack(x, y, this.r));
                arr.splice(idx, 1);
            }
        });
        endShape(CLOSE);        
    }
}