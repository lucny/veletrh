class Crack {
    constructor(posX, posY, radius) {
        this.x = posX;
        this.y = posY;
        this.r = radius;
        this.crackpoints = [];
        this.color = `rgba(${round(random(156))}, ${round(random(156))}, ${round(random(156))}, ${random(0, 1)})`;
        print(this.color);
        this.generatePoints();
    }
    
    generatePoints() {
        for (let i = 1; i <= this.r; i++) {
            let dist = random(this.r * 2 / 3, this.r);
            point = {
                x: this.x + round((cos((2 * PI / this.r) * i)) * dist),
                y: this.y + round((sin((2 * PI / this.r) * i)) * dist)
            }   
            print(point);         
            this.crackpoints.push(point);
        }
        print(this.crackpoints);
    }

    pulse() {
        this.crackpoints.map((point, idx, arr) => {
            point.x += random(-1, 1);
            point.y += random(-1, 1);
        });
    }

    draw() {
        this.pulse();
        noFill();
        stroke(this.color);
        beginShape();
        this.x += random(-2, 2);
        this.y += random(-2, 2);
        this.crackpoints.forEach((point) => {
            curveVertex(point.x, point.y);
            circle(point.x, point.y, 5);
            line(this.x, this.y, point.x, point.y);
        });
        endShape(CLOSE);        
    }
}