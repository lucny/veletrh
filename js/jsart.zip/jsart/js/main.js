let cracks = [];
let keyframe;
let pozadi;

/* Funkce pro základní nastavení aplikace v P5 JS */
function setup() {
  /* Vytvoří plátno podle velikosti displeje: https://p5js.org/reference/#/p5/createCanvas */
  canvas = createCanvas(displayWidth, displayHeight);
}

/* Funkce pro vykreslení plátna */
function draw() {
  /* Nastaví černou barvu pozadí: https://p5js.org/reference/#/p5/background */
  background(0);
  push();
  translate(width/2, height/2);
  rotate((2*PI/360) * frameCount / 30);
  image(pozadi, -width, -height, width * 2, height * 2);
  pop();
  cracks.forEach((crack, idx, arr) => {
    crack.draw();
  });
}

function preload() {
  pozadi = loadImage('/img/pozadi3.jpg');
}

/* Funkce pro změnu velikosti plátna podle velikosti okna */
function windowResized() {
  /* Změní velikost plátna podle rozměrů okna: https://p5js.org/reference/#/p5/resizeCanvas */
  resizeCanvas(windowWidth, windowHeight);
  for (let i = 0; i < 100; i ++) {
    cracks.push(new Crack(random(10, width - 20), random(10, height - 20), random(3, 5)));
  }
}

function mousePressed() {
  keyframe = frameCount;
}

function mouseReleased() {
  cracks.push(new Crack(mouseX, mouseY, frameCount - keyframe));
}
