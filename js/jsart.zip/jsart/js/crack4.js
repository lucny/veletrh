class Crack {
    constructor(posX, posY, radius) {
        this.x = posX;
        this.y = posY;
        this.dx = random(-5, 5);
        this.dy = random(-5, 5);
        this.r = radius;        
        this.crackpoints = [];
        this.color = `rgba(${round(random(156))}, ${round(random(156))}, ${round(random(156))}, ${random(0, 1)})`;
        this.frames = frameCount;
        this.reverse = false;
        this.generatePoints(this.r);
    }
    
    generatePoints(dist) {
        for (let i = 1; i <= this.r; i++) {
            point = {
                angle: (2 * PI / this.r) * i,
                dist: dist
            }   
            this.crackpoints.push(point);
        }
    }

    move() {
        this.x += this.dx;
        this.y += this.dy;
        if (this.x < 10 || this.x > width - 20) this.dx = -this.dx;
        if (this.y < 10 || this.y > height - 20) this.dy = -this.dy;
    }

    pulse() {
        this.crackpoints.map((point, idx, arr) => {
            point.dist += random(-20, 20);
        });
    }

    draw() {
        this.pulse();
        this.move();
        fill(this.color);
        stroke(this.color);
        strokeWeight(1);
        //smooth();
        beginShape();
        this.crackpoints.forEach((point, idx, arr) => {
            this.reverse ? point.dist *= 0.998 : point.dist *= 1.002;
            let x0 = this.x + round((cos(point.angle) * (point.dist - 10))); 
            let y0 = this.y + round((sin(point.angle) * (point.dist - 10)));
            let x = this.x + round((cos(point.angle) * point.dist)); 
            let y = this.y + round((sin(point.angle) * point.dist));
            curveVertex(x, y);
        });
        if (frameCount - this.frames > 1000) {
            /*this.crackpoints.map((point) => {
               point.dist = this.r; 
            })*/
            this.frames = frameCount;
            this.reverse = !this.reverse;
        }            
        endShape(CLOSE);        
    }
}