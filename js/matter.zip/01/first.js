let engine = Matter.Engine.create();

const cat = {
    static:    0x0001,
    nodrag:    0x0002,
    drag:      0x0004
};

let render = Matter.Render.create({
  element: document.querySelector("main"),
  engine: engine,
  options: {
    width: 1600,
    height: 700,
    wireframes: true,
  },
});

let ground = Matter.Bodies.rectangle(1200, 400, 300, 20, { isStatic: true });
let wall1 = Matter.Bodies.rectangle(800, 300, 30, 300, { isStatic: true });
let wall2 = Matter.Bodies.rectangle(1400, 200, 30, 200, { isStatic: true });
wall1.restitution = 0.5;
wall2.restitution = 0.5;

let ball = Matter.Bodies.circle(300, 500, 20);
let sling = Matter.Constraint.create({
  pointA: { x: 300, y: 500 },
  bodyB: ball,
  stiffness: 0.05,
});

let mouse = Matter.Mouse.create(render.canvas);
let mouseConstraint = Matter.MouseConstraint.create(engine, {
  mouse: mouse,
  constraint: {
    render: { visible: false },
  },
});

render.mouse = mouse;

let firing = false;
let shots = 0;
let energy = 0;
let start = new Date();

Matter.Events.on(mouseConstraint, "enddrag", function (e) {
  if (e.body === ball) { 
      firing = true;
      console.log(sling.bodyB.force);
      shots++;
      ball.collisionFilter.category = cat.nodrag;
  }  
});

Matter.Events.on(engine, "afterUpdate", function () {
  if (
    firing &&
    Math.abs(ball.position.x - 300) < 20 &&
    Math.abs(ball.position.y - 500) < 20
  ) {
    ball = Matter.Bodies.circle(300, 500, 20); 
    //ball = Matter.Bodies.polygon(300, 500, 3, 20);
    Matter.World.add(engine.world, ball);
    sling.bodyB = ball;
    firing = false;
  }
  let points = 16;
  stack.bodies.forEach(element => {
      if (element.position.y <= 400) points--;
  });
  console.log(shots, points);
  let stop = new Date();
  document.getElementById('shots').innerText = shots;
  document.getElementById('points').innerText = points;
  document.getElementById('time').innerText = (new Date(stop - start)).toLocaleTimeString().slice(-5);
});

let stack = Matter.Composites.stack(1100, 170, 4, 4, 0, 0, function (x, y) {
  return Matter.Bodies.polygon(x, y, 8, 30, { collisionFilter: { category: cat.nodrag }});
});

mouseConstraint.collisionFilter.mask = cat.static | cat.drag;

Matter.World.add(engine.world, [stack, ground, wall1, wall2, ball, sling, mouseConstraint]);
Matter.Runner.run(engine);
Matter.Render.run(render);
