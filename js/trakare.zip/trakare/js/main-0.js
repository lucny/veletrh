let trakarImg, pajdulakImg;
let trakare = [];
let pajdulak;
let soundHit;

class Trakar {
  constructor(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  draw() {
    fill('white');
    //rect(this.x, this.y, this.w, this.h);
    image(trakarImg, this.x, this.y, this.w, this.h);
  }
} 

class Pajdulak {
  constructor(x, h) {
    this.x = x;
    this.h = h;
    this.y = height - this.h;
    this.w = 40;
    this.live = 5;
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      if (this.x > 0) this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      if (this.x < width - this.w) this.x += 5;
    }
  }

  draw() {
    this.move();
    fill(255, 0, 0, 127);
    //rect(this.x, this.y, this.w, this.h);
    image(pajdulakImg, this.x, this.y, this.w, this.h);
  }
} 

function preload() {
  pajdulakImg = loadImage('/img/pajdulak.png');
  trakarImg = loadImage('/img/vozik.png');
  soundHit = loadSound('sounds/hit-sound.mp3');  
}

/* Funkce pro základní nastavení aplikace v P5 JS */
function setup() {
  /* Vytvoří plátno podle velikosti displeje: https://p5js.org/reference/#/p5/createCanvas */
  canvas = createCanvas(displayWidth, displayHeight);
  // trakar = new Trakar(200, 100, 200, 100);
  pajdulak = new Pajdulak(300, 100);
}

/* Funkce pro vykreslení plátna */
function draw() {
  /* Nastaví černou barvu pozadí: https://p5js.org/reference/#/p5/background */
  background(0);
  trakare.forEach((trakar, idx, arr) => {
    trakar.y++;
    trakar.draw();
    if (collideRectRect(
      trakar.x, trakar.y, trakar.w, trakar.h, 
      pajdulak.x, pajdulak.y, pajdulak.w, pajdulak.h
      )) {
        pajdulak.live--;
        arr.splice(idx, 1);
        print(pajdulak.live);
        soundHit.play();
    }
    if (trakar.y > height) {
      arr.splice(idx, 1);
    }
  });
  if (pajdulak.live === 0) {
    noLoop();
  }
  pajdulak.draw();
}

/* Funkce pro změnu velikosti plátna podle velikosti okna */
function windowResized() {
  /* Změní velikost plátna podle rozměrů okna: https://p5js.org/reference/#/p5/resizeCanvas */
  resizeCanvas(windowWidth, windowHeight);
  pajdulak.y = height - pajdulak.h;
}

function mousePressed() {
  trakare.push(new Trakar(mouseX, mouseY, random(50, 100), random(25, 50)));
}